console.log("SQL Saver content script loaded");const s=[".CodeMirror",".monaco-editor",'[data-testid="sql-editor"]','textarea[class*="sql"]','textarea[class*="query"]','div[class*="sql-editor"]','div[class*="query-editor"]'];chrome.runtime.onMessage.addListener((e,t,o)=>{var i;if(e.type==="GET_SELECTED_TEXT"){const n=(i=window.getSelection())==null?void 0:i.toString();n&&n.trim()&&chrome.runtime.sendMessage({type:"SAVE_QUERY",data:{query:n,source:window.location.href}}),o({success:!0})}return e.type==="COPY_TO_CLIPBOARD"&&(navigator.clipboard.writeText(e.data.text).then(()=>{console.log("Text copied to clipboard"),d("Copied to clipboard!")}),o({success:!0})),!0});function a(){for(const e of s){const t=document.querySelector(e);if(t)return t}return null}function d(e){const t=document.createElement("div");t.textContent=e,t.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    background: #5b5fff;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px;
    animation: slideIn 0.3s ease;
  `;const o=document.createElement("style");o.textContent=`
    @keyframes slideIn {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `,document.head.appendChild(o),document.body.appendChild(t),setTimeout(()=>{t.style.animation="slideIn 0.3s ease reverse",setTimeout(()=>t.remove(),300)},2e3)}document.addEventListener("keydown",e=>{var t;if((e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="S"){e.preventDefault();const o=(t=window.getSelection())==null?void 0:t.toString();o&&o.trim()&&(chrome.runtime.sendMessage({type:"SAVE_QUERY",data:{query:o,source:window.location.href}}),chrome.runtime.sendMessage({type:"OPEN_SIDE_PANEL"}))}});const r=a();r&&console.log("SQL editor detected:",r);
